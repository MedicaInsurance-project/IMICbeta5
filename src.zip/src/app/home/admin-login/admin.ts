// tslint:disable-next-line:class-name
export class adminLogin {
    constructor(
        public seviceUsername: string,
        public  sevicePassword: string,

    ) { }
}
