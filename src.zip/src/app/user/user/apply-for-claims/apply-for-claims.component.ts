import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-for-claims',
  templateUrl: './apply-for-claims.component.html',
  styleUrls: ['./apply-for-claims.component.css']
})
export class ApplyForClaimsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
